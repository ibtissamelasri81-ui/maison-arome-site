import { motion } from 'motion/react';
import { Award, Heart, Leaf, Users } from 'lucide-react';

const values = [
  {
    icon: Award,
    title: 'Excellence',
    description: 'Un savoir-faire artisanal français transmis depuis des générations',
  },
  {
    icon: Heart,
    title: 'Passion',
    description: 'Chaque création est le fruit d\'un amour profond pour la parfumerie',
  },
  {
    icon: Leaf,
    title: 'Naturel',
    description: 'Des ingrédients nobles et naturels soigneusement sélectionnés',
  },
  {
    icon: Users,
    title: 'Sur Mesure',
    description: 'Une attention personnalisée pour révéler votre essence unique',
  },
];

export function About() {
  return (
    <section id="a-propos" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-sm tracking-[0.3em] text-[#D4AF37] mb-4 uppercase">
            Notre Histoire
          </p>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-light text-[#2A2A2A] mb-6">
            À Propos de MAISON AROME
          </h2>
          <div className="w-24 h-px bg-[#D4AF37] mx-auto mb-6" />
        </motion.div>

        {/* Story */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto text-center mb-20"
        >
          <p className="text-lg text-[#2A2A2A] mb-6 leading-relaxed">
            Depuis notre création, MAISON AROME incarne l'élégance et le raffinement
            de la parfumerie française.
          </p>
          <p className="text-base text-[#666666] leading-relaxed mb-6">
            Notre maison de parfums vous propose une sélection exclusive de fragrances :
            deux créations dédiées aux femmes, deux créations pour les hommes, ainsi qu'un
            service unique de parfums personnalisés conçus selon vos envies et vos arômes préférés.
          </p>
          <p className="text-base text-[#666666] leading-relaxed">
            Chaque parfum est une invitation à explorer un monde parfumé où se mêlent tradition
            artisanale et innovation olfactive. Laissez-vous séduire par nos fragrances uniques
            et composez votre parfum sur mesure pour une expérience inoubliable.
          </p>
        </motion.div>

        {/* Values Grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((value, index) => (
            <motion.div
              key={value.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              className="text-center group"
            >
              <div className="w-20 h-20 mx-auto mb-6 bg-[#FAFAFA] border border-[#D4AF37]/20 flex items-center justify-center group-hover:bg-[#D4AF37] transition-all duration-500">
                <value.icon className="w-10 h-10 text-[#D4AF37] group-hover:text-white transition-colors duration-500" />
              </div>
              <h3 className="text-xl text-[#2A2A2A] mb-3 tracking-wide">{value.title}</h3>
              <p className="text-sm text-[#666666] leading-relaxed">{value.description}</p>
            </motion.div>
          ))}
        </div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-center mt-16"
        >
          <p className="text-base text-[#666666] mb-6">
            Prêt à découvrir votre signature olfactive ?
          </p>
          <button className="px-12 py-4 bg-[#D4AF37] text-white tracking-widest transition-all duration-500 hover:bg-[#B8941F] shadow-lg hover:shadow-xl">
            <span className="text-sm font-medium">EXPLORER NOS CRÉATIONS</span>
          </button>
        </motion.div>
      </div>
    </section>
  );
}
