import { motion } from 'motion/react';
import { ProductCard } from './ProductCard';

const products = [
  {
    name: 'Belle Aurore',
    description: 'Rose & Jasmin',
    price: '€185',
    category: 'POUR ELLE',
    image: 'https://images.unsplash.com/photo-1761014219737-66c547f50a61?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHBlcmZ1bWUlMjBlbGVnYW50JTIwd2hpdGV8ZW58MXx8fHwxNzcxMDk0NDU3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  },
  {
    name: 'Éclat de Nuit',
    description: 'Vanille & Ambre Noir',
    price: '€195',
    category: 'POUR ELLE',
    image: 'https://images.unsplash.com/photo-1655500061669-1f8ac338a319?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVnYW50JTIwcGVyZnVtZSUyMGNvbGxlY3Rpb258ZW58MXx8fHwxNzcwOTcxNjA4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  },
  {
    name: 'Homme Élégant',
    description: 'Bois de Cèdre & Vétiver',
    price: '€175',
    category: 'POUR LUI',
    image: 'https://images.unsplash.com/photo-1758871992965-836e1fb0f9bc?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtYW4lMjBjb2xvZ25lJTIwYm90dGxlJTIwbHV4dXJ5fGVufDF8fHx8MTc3MTA5NDQ1N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  },
  {
    name: 'Aventure Royale',
    description: 'Oud & Cuir',
    price: '€205',
    category: 'POUR LUI',
    image: 'https://images.unsplash.com/photo-1770301410072-f6ef6dad65b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwZXJmdW1lJTIwYm90dGxlJTIwZ29sZHxlbnwxfHx8fDE3NzA4NzA0Njd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  },
];

export function FeaturedProducts() {
  return (
    <section id="parfums" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-sm tracking-[0.3em] text-[#D4AF37] mb-4 uppercase">
            Notre Collection
          </p>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-light text-[#2A2A2A] mb-6">
            Nos Parfums Signature
          </h2>
          <div className="w-24 h-px bg-[#D4AF37] mx-auto mb-6" />
          <p className="text-base text-[#666666] max-w-2xl mx-auto">
            Deux créations exclusives pour elle, deux pour lui.
            <br className="hidden sm:block" />
            Chaque fragrance raconte une histoire unique
          </p>
        </motion.div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {products.map((product, index) => (
            <ProductCard key={product.name} {...product} index={index} />
          ))}
        </div>

        {/* Collection Info */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-center max-w-3xl mx-auto mt-16 p-8 bg-[#FAFAFA] border border-[#D4AF37]/20"
        >
          <h3 className="text-2xl font-light text-[#2A2A2A] mb-4">
            Laissez-vous séduire par nos fragrances uniques
          </h3>
          <p className="text-sm text-[#666666] leading-relaxed">
            Chaque parfum de notre collection est le fruit d'un savoir-faire artisanal français.
            Des matières premières nobles sélectionnées avec soin pour créer des compositions
            olfactives inoubliables qui révèlent votre personnalité.
          </p>
        </motion.div>
      </div>
    </section>
  );
}
