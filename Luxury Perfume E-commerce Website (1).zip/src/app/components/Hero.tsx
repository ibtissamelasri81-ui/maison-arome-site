import { motion } from 'motion/react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { Sparkles } from 'lucide-react';

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gradient-to-b from-white via-[#FAFAFA] to-white">
      {/* Decorative Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle, #D4AF37 1px, transparent 1px)',
          backgroundSize: '50px 50px'
        }} />
      </div>

      {/* Background Image */}
      <div className="absolute inset-0 opacity-20">
        <ImageWithFallback
          src="https://images.unsplash.com/photo-1770301410072-f6ef6dad65b2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBwZXJmdW1lJTIwYm90dGxlJTIwZ29sZHxlbnwxfHx8fDE3NzA4NzA0Njd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
          alt="Luxury perfume"
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center pt-20">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.3 }}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 1, delay: 0.5 }}
            className="flex items-center justify-center gap-3 mb-6"
          >
            <Sparkles className="w-5 h-5 text-[#D4AF37]" />
            <p className="text-sm tracking-[0.3em] text-[#D4AF37] uppercase">
              Parfumerie de Luxe
            </p>
            <Sparkles className="w-5 h-5 text-[#D4AF37]" />
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.7 }}
            className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl font-light text-[#2A2A2A] mb-6 tracking-wide"
          >
            Bienvenue chez
            <br />
            <span className="text-[#D4AF37] italic">MAISON AROME</span>
          </motion.h2>
          
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.9 }}
            className="text-base sm:text-lg text-[#666666] max-w-3xl mx-auto mb-4 leading-relaxed"
          >
            L'univers lumineux et élégant de la parfumerie de luxe
          </motion.p>
          
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 1.1 }}
            className="text-sm sm:text-base text-[#666666] max-w-2xl mx-auto mb-12 leading-relaxed"
          >
            Découvrez notre sélection exclusive : 2 créations pour femmes, 2 pour hommes,
            <br className="hidden sm:block" />
            ainsi que des parfums personnalisés conçus selon vos envies
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 1.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <button className="group relative px-12 py-4 bg-[#D4AF37] text-white tracking-widest overflow-hidden transition-all duration-500 hover:bg-[#B8941F] shadow-lg hover:shadow-xl">
              <span className="relative z-10 text-sm font-medium">DÉCOUVRIR NOS PARFUMS</span>
            </button>
            
            <button className="px-12 py-4 border-2 border-[#D4AF37] text-[#D4AF37] tracking-widest transition-all duration-500 hover:bg-[#D4AF37] hover:text-white">
              <span className="text-sm font-medium">CRÉER VOTRE PARFUM</span>
            </button>
          </motion.div>
        </motion.div>

        {/* Scroll Indicator */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 1.5 }}
          className="absolute bottom-12 left-1/2 transform -translate-x-1/2"
        >
          <motion.div
            animate={{ y: [0, 10, 0] }}
            transition={{ duration: 2, repeat: Infinity, ease: 'easeInOut' }}
            className="w-6 h-10 border-2 border-[#D4AF37]/40 rounded-full flex items-start justify-center p-2"
          >
            <motion.div className="w-1 h-2 bg-[#D4AF37] rounded-full" />
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
}
