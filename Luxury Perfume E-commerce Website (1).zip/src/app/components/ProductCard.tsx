import { motion } from 'motion/react';
import { ShoppingBag, Heart } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface ProductCardProps {
  name: string;
  description: string;
  price: string;
  image: string;
  index: number;
  category?: string;
}

export function ProductCard({ name, description, price, image, index, category }: ProductCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      className="group relative bg-white"
    >
      <div className="relative overflow-hidden bg-[#F5F5F5] aspect-[3/4] mb-4">
        <ImageWithFallback
          src={image}
          alt={name}
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-white/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
        
        {/* Category Badge */}
        {category && (
          <div className="absolute top-4 left-4 px-4 py-1 bg-white/90 backdrop-blur-sm">
            <span className="text-xs tracking-wider text-[#D4AF37]">{category}</span>
          </div>
        )}
        
        {/* Favorite Button */}
        <motion.button
          whileHover={{ scale: 1.1 }}
          className="absolute top-4 right-4 w-10 h-10 bg-white/90 backdrop-blur-sm flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500 hover:bg-[#D4AF37] hover:text-white"
        >
          <Heart className="w-5 h-5" />
        </motion.button>
        
        {/* Add to cart button */}
        <motion.button
          whileHover={{ scale: 1.02 }}
          className="absolute bottom-6 left-1/2 transform -translate-x-1/2 w-[calc(100%-3rem)] px-8 py-3 bg-[#D4AF37] text-white tracking-widest opacity-0 group-hover:opacity-100 transition-all duration-500 flex items-center justify-center gap-2 hover:bg-[#B8941F]"
        >
          <ShoppingBag className="w-4 h-4" />
          <span className="text-sm font-medium">AJOUTER AU PANIER</span>
        </motion.button>
      </div>
      
      <div className="text-center space-y-2 px-4">
        <h3 className="text-xl tracking-wide text-[#2A2A2A]">{name}</h3>
        <p className="text-sm text-[#666666]">{description}</p>
        <p className="text-lg text-[#D4AF37] tracking-wide">{price}</p>
      </div>
    </motion.div>
  );
}
