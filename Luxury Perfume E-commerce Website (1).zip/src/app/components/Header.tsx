import { ShoppingBag, Menu, X } from 'lucide-react';
import { motion } from 'motion/react';
import { useState } from 'react';

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <motion.header
      initial={{ y: -100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.8, ease: 'easeOut' }}
      className="fixed top-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-md border-b border-[#D4AF37]/20 shadow-sm"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          {/* Shopping Cart - Left */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="flex items-center gap-2"
          >
            <button
              className="text-[#2A2A2A] hover:text-[#D4AF37] transition-colors duration-300 relative"
              aria-label="Shopping bag"
            >
              <ShoppingBag className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#D4AF37] text-white text-xs rounded-full flex items-center justify-center">
                0
              </span>
            </button>
          </motion.div>

          {/* Logo - Center */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3, duration: 0.8 }}
            className="absolute left-1/2 transform -translate-x-1/2"
          >
            <h1 className="text-2xl sm:text-3xl font-light tracking-[0.3em] text-[#D4AF37]">
              MAISON AROME
            </h1>
          </motion.div>

          {/* Desktop Navigation - Right */}
          <nav className="hidden md:flex items-center space-x-8">
            {['Parfums', 'Arome', 'À propos', 'FAQ', 'Contact'].map((item, index) => (
              <motion.a
                key={item}
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + index * 0.1, duration: 0.6 }}
                href={`#${item.toLowerCase().replace(' ', '-').replace('à', 'a')}`}
                className="text-sm tracking-wider text-[#2A2A2A] hover:text-[#D4AF37] transition-colors duration-300"
              >
                {item}
              </motion.a>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden text-[#2A2A2A] hover:text-[#D4AF37] transition-colors duration-300"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Menu"
          >
            {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden py-4 border-t border-[#D4AF37]/20"
          >
            <nav className="flex flex-col space-y-4">
              {['Parfums', 'Arome', 'À propos', 'FAQ', 'Contact'].map((item) => (
                <a
                  key={item}
                  href={`#${item.toLowerCase().replace(' ', '-').replace('à', 'a')}`}
                  className="text-sm tracking-wider text-[#2A2A2A] hover:text-[#D4AF37] transition-colors duration-300"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item}
                </a>
              ))}
            </nav>
          </motion.div>
        )}
      </div>
    </motion.header>
  );
}
