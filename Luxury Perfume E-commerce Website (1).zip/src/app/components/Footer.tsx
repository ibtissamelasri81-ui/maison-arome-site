import { motion } from 'motion/react';
import { Instagram, Facebook, Mail, MapPin, Phone } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-[#FAFAFA] border-t border-[#D4AF37]/20 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
          >
            <h3 className="text-2xl font-light tracking-[0.3em] text-[#D4AF37] mb-4">
              MAISON AROME
            </h3>
            <p className="text-sm text-[#666666] leading-relaxed mb-6">
              L'univers lumineux et élégant de la parfumerie de luxe française
            </p>
            <div className="flex gap-4">
              <a
                href="#"
                className="w-10 h-10 border border-[#D4AF37]/30 flex items-center justify-center hover:bg-[#D4AF37] hover:text-white transition-all duration-300"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-10 h-10 border border-[#D4AF37]/30 flex items-center justify-center hover:bg-[#D4AF37] hover:text-white transition-all duration-300"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="#"
                className="w-10 h-10 border border-[#D4AF37]/30 flex items-center justify-center hover:bg-[#D4AF37] hover:text-white transition-all duration-300"
                aria-label="Email"
              >
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </motion.div>

          {/* Navigation */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
          >
            <h4 className="text-sm tracking-[0.2em] text-[#2A2A2A] mb-6 uppercase">Navigation</h4>
            <ul className="space-y-3">
              {['Parfums', 'Arome', 'À propos', 'FAQ', 'Contact'].map((item) => (
                <li key={item}>
                  <a href={`#${item.toLowerCase().replace(' ', '-').replace('à', 'a')}`} className="text-sm text-[#666666] hover:text-[#D4AF37] transition-colors duration-300">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Services */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <h4 className="text-sm tracking-[0.2em] text-[#2A2A2A] mb-6 uppercase">Services</h4>
            <ul className="space-y-3">
              {['Parfums Pour Elle', 'Parfums Pour Lui', 'Création Sur Mesure', 'Livraison Premium'].map((item) => (
                <li key={item}>
                  <a href="#" className="text-sm text-[#666666] hover:text-[#D4AF37] transition-colors duration-300">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </motion.div>

          {/* Contact */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            id="contact"
          >
            <h4 className="text-sm tracking-[0.2em] text-[#2A2A2A] mb-6 uppercase">Contact</h4>
            <ul className="space-y-4 text-sm text-[#666666]">
              <li className="flex items-start gap-3">
                <MapPin className="w-4 h-4 text-[#D4AF37] mt-1 flex-shrink-0" />
                <span>25 Avenue Montaigne<br />75008 Paris, France</span>
              </li>
              <li className="flex items-center gap-3">
                <Phone className="w-4 h-4 text-[#D4AF37] flex-shrink-0" />
                <a href="tel:+33142563489" className="hover:text-[#D4AF37] transition-colors duration-300">
                  +33 1 42 56 34 89
                </a>
              </li>
              <li className="flex items-center gap-3">
                <Mail className="w-4 h-4 text-[#D4AF37] flex-shrink-0" />
                <a href="mailto:contact@maisonarome.fr" className="hover:text-[#D4AF37] transition-colors duration-300">
                  contact@maisonarome.fr
                </a>
              </li>
            </ul>
          </motion.div>
        </div>

        {/* Newsletter */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="border-t border-[#D4AF37]/20 pt-12 mb-12"
        >
          <div className="max-w-2xl mx-auto text-center">
            <h4 className="text-sm tracking-[0.2em] text-[#2A2A2A] mb-4 uppercase">
              Newsletter
            </h4>
            <p className="text-sm text-[#666666] mb-6">
              Recevez nos actualités et offres exclusives
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Votre adresse email"
                className="flex-1 px-6 py-3 bg-white border border-[#D4AF37]/30 text-[#2A2A2A] placeholder:text-[#999999] focus:outline-none focus:border-[#D4AF37] transition-colors duration-300"
              />
              <button className="px-8 py-3 bg-[#D4AF37] text-white tracking-widest transition-all duration-500 hover:bg-[#B8941F] whitespace-nowrap shadow-md hover:shadow-lg">
                <span className="text-sm font-medium">S'INSCRIRE</span>
              </button>
            </div>
          </div>
        </motion.div>

        {/* Copyright */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center text-xs text-[#999999] tracking-wider"
        >
          <p>© 2026 MAISON AROME. Tous droits réservés.</p>
        </motion.div>
      </div>
    </footer>
  );
}
