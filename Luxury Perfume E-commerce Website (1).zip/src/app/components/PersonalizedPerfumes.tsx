import { motion } from 'motion/react';
import { Sparkles, Droplets, FlaskConical, Star } from 'lucide-react';
import { ImageWithFallback } from './figma/ImageWithFallback';

const features = [
  {
    icon: Sparkles,
    title: 'Consultation Personnalisée',
    description: 'Un rendez-vous privé pour comprendre vos préférences olfactives',
  },
  {
    icon: Droplets,
    title: 'Vos Arômes Préférés',
    description: 'Sélection des essences qui correspondent à votre personnalité',
  },
  {
    icon: FlaskConical,
    title: 'Création Artisanale',
    description: 'Votre parfum unique, composé à la main dans nos ateliers',
  },
  {
    icon: Star,
    title: 'Formule Exclusive',
    description: 'Une signature olfactive qui vous appartient pour toujours',
  },
];

export function PersonalizedPerfumes() {
  return (
    <section id="arome" className="py-24 bg-gradient-to-b from-white via-[#FAFAFA] to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-sm tracking-[0.3em] text-[#D4AF37] mb-4 uppercase">
            Service Exclusif
          </p>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-light text-[#2A2A2A] mb-6">
            Parfums Personnalisés
          </h2>
          <div className="w-24 h-px bg-[#D4AF37] mx-auto mb-6" />
          <p className="text-base text-[#666666] max-w-2xl mx-auto">
            Composez votre parfum sur mesure pour une expérience olfactive inoubliable
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Image Side */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative order-2 lg:order-1"
          >
            <div className="relative aspect-[4/5] overflow-hidden shadow-xl">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1622952826417-6212791163ab?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdXN0b20lMjBwZXJmdW1lJTIwaW5ncmVkaWVudHN8ZW58MXx8fHwxNzcxMDk0NDU3fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Custom perfume ingredients"
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Decorative elements */}
            <div className="absolute -top-6 -right-6 w-48 h-48 border-2 border-[#D4AF37]/30 -z-10" />
            <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-[#D4AF37]/10 -z-10" />
          </motion.div>

          {/* Content Side */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="order-1 lg:order-2"
          >
            <p className="text-base text-[#666666] mb-8 leading-relaxed">
              Chez MAISON AROME, nous croyons que chaque personne mérite un parfum unique.
              Notre service de parfumerie sur mesure vous permet de créer une fragrance
              qui reflète parfaitement votre essence et vos envies.
            </p>

            {/* Features Grid */}
            <div className="grid sm:grid-cols-2 gap-6 mb-10">
              {features.map((feature, index) => (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  className="bg-white p-6 border border-[#D4AF37]/20 hover:border-[#D4AF37]/50 transition-all duration-300 hover:shadow-lg group"
                >
                  <div className="w-12 h-12 bg-[#D4AF37]/10 flex items-center justify-center mb-4 group-hover:bg-[#D4AF37]/20 transition-colors duration-300">
                    <feature.icon className="w-6 h-6 text-[#D4AF37]" />
                  </div>
                  <h3 className="text-base text-[#2A2A2A] mb-2">{feature.title}</h3>
                  <p className="text-sm text-[#666666] leading-relaxed">{feature.description}</p>
                </motion.div>
              ))}
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              className="w-full sm:w-auto px-12 py-4 bg-[#D4AF37] text-white tracking-widest transition-all duration-500 hover:bg-[#B8941F] shadow-lg hover:shadow-xl"
            >
              <span className="text-sm font-medium">CRÉER MON PARFUM</span>
            </motion.button>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
