import { motion } from 'motion/react';
import { Plus, Minus } from 'lucide-react';
import { useState } from 'react';

const faqs = [
  {
    question: 'Combien de temps faut-il pour créer un parfum personnalisé ?',
    answer: 'La création d\'un parfum personnalisé prend généralement entre 2 et 4 semaines. Ce délai inclut votre consultation initiale, la composition de votre fragrance unique, et la période de maturation nécessaire pour révéler toutes les nuances de votre parfum.',
  },
  {
    question: 'Quelle est la différence entre vos parfums pour femmes et pour hommes ?',
    answer: 'Nos deux parfums pour femmes mettent en valeur des notes florales et orientales raffinées, tandis que nos deux créations pour hommes privilégient des accords boisés et épicés. Cependant, chaque fragrance est unisexe et peut être portée selon vos préférences personnelles.',
  },
  {
    question: 'Comment se déroule une consultation pour un parfum sur mesure ?',
    answer: 'Lors de votre consultation privée, notre maître parfumeur prend le temps de comprendre vos goûts, votre personnalité et vos souvenirs olfactifs. Vous découvrirez différentes familles d\'arômes, sélectionnerez vos notes préférées, et ensemble, vous composerez une fragrance unique qui vous ressemble.',
  },
  {
    question: 'Vos parfums sont-ils fabriqués avec des ingrédients naturels ?',
    answer: 'Oui, nous privilégions les ingrédients naturels et nobles dans toutes nos créations. Chaque essence est soigneusement sélectionnée pour sa qualité exceptionnelle et provient de producteurs respectant des pratiques durables.',
  },
  {
    question: 'Quelle est la durée de conservation d\'un parfum ?',
    answer: 'Nos parfums ont une durée de vie de 3 à 5 ans s\'ils sont conservés dans de bonnes conditions : à l\'abri de la lumière directe, de la chaleur et de l\'humidité. Pour préserver au mieux votre fragrance, gardez-la dans son coffret d\'origine.',
  },
  {
    question: 'Proposez-vous des échantillons avant l\'achat ?',
    answer: 'Oui, nous proposons des coffrets découverte contenant des miniatures de nos quatre parfums signature. C\'est le moyen idéal de découvrir nos créations avant de choisir votre fragrance préférée en format standard.',
  },
  {
    question: 'Livrez-vous partout en France ?',
    answer: 'Oui, nous livrons dans toute la France métropolitaine. Chaque commande est soigneusement emballée et expédiée sous 48h. Nous proposons également une livraison premium avec emballage luxe pour vos cadeaux.',
  },
  {
    question: 'Puis-je offrir un bon cadeau pour un parfum personnalisé ?',
    answer: 'Absolument ! Nous proposons des bons cadeaux pour notre service de parfumerie sur mesure. C\'est le cadeau parfait pour offrir une expérience unique et permettre à vos proches de créer leur fragrance signature.',
  },
];

export function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="py-24 bg-[#FAFAFA]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <p className="text-sm tracking-[0.3em] text-[#D4AF37] mb-4 uppercase">
            Questions Fréquentes
          </p>
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-light text-[#2A2A2A] mb-6">
            FAQ
          </h2>
          <div className="w-24 h-px bg-[#D4AF37] mx-auto mb-6" />
          <p className="text-base text-[#666666] max-w-2xl mx-auto">
            Retrouvez ici les réponses aux questions les plus fréquemment posées
          </p>
        </motion.div>

        {/* FAQ List */}
        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              className="bg-white border border-[#D4AF37]/20 overflow-hidden"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full px-6 py-5 flex items-center justify-between text-left hover:bg-[#FAFAFA] transition-colors duration-300"
              >
                <span className="text-base text-[#2A2A2A] pr-4">
                  {faq.question}
                </span>
                <span className="flex-shrink-0 w-8 h-8 bg-[#D4AF37]/10 flex items-center justify-center transition-colors duration-300">
                  {openIndex === index ? (
                    <Minus className="w-4 h-4 text-[#D4AF37]" />
                  ) : (
                    <Plus className="w-4 h-4 text-[#D4AF37]" />
                  )}
                </span>
              </button>
              <motion.div
                initial={false}
                animate={{
                  height: openIndex === index ? 'auto' : 0,
                  opacity: openIndex === index ? 1 : 0,
                }}
                transition={{ duration: 0.3 }}
                className="overflow-hidden"
              >
                <div className="px-6 pb-5 text-sm text-[#666666] leading-relaxed border-t border-[#D4AF37]/10">
                  <p className="pt-4">{faq.answer}</p>
                </div>
              </motion.div>
            </motion.div>
          ))}
        </div>

        {/* Contact CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4 }}
          className="text-center mt-12 p-8 bg-white border border-[#D4AF37]/20"
        >
          <p className="text-base text-[#2A2A2A] mb-4">
            Vous avez d'autres questions ?
          </p>
          <p className="text-sm text-[#666666] mb-6">
            Notre équipe est à votre disposition pour répondre à toutes vos interrogations
          </p>
          <a
            href="#contact"
            className="inline-block px-10 py-3 border-2 border-[#D4AF37] text-[#D4AF37] tracking-widest transition-all duration-500 hover:bg-[#D4AF37] hover:text-white"
          >
            <span className="text-sm font-medium">NOUS CONTACTER</span>
          </a>
        </motion.div>
      </div>
    </section>
  );
}
