
  # Luxury Perfume E-commerce Website

  This is a code bundle for Luxury Perfume E-commerce Website. The original project is available at https://www.figma.com/design/WX3g8rm0y1Rd6S6Qro8D62/Luxury-Perfume-E-commerce-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  